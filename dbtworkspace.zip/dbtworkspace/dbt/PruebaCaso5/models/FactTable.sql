{{ config(materialized='view') }}

SELECT DS2.idServicio, DS2.id, DS2.FechaSolicitada, DS2.Estado, DS1.Costo
FROM {{ source('Data_Datasets', 'DATASET_1') }} AS DS1
INNER JOIN {{ source('Data_Datasets', 'DATASET_1') }} AS DS2
    ON DS2.idServicio = DS1.id
