{{ config(materialized='table') }}

WITH users_raw_data AS (
    SELECT id, firstName, lastName, email, telephone, sex
    FROM {{ source('UsersData', 'Users') }}
)

SELECT id, firstName, lastName, email, telephone, sex
FROM users_raw_data;